﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Runtime;
using System.Diagnostics;
using Logic;

namespace SafeTransfer.ViewModels
{

    public class MainWindowViewModel : INotifyPropertyChanged
    {
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public event PropertyChangedEventHandler PropertyChanged;



        public string DecryptedString
        {
            get => Encoding.UTF8.GetString(_decrypted);
            set
            {
                _decrypted = Encoding.UTF8.GetBytes(value);
                OnPropertyChanged();
            }
        }


        private byte[] _decrypted;

        public byte[] Decrypted 
        {
            get => _decrypted;
            set
            { 
                _decrypted = value;
                Encrypted = Encrypt(value);
                OnPropertyChanged();
                OnPropertyChanged(nameof(DecryptedString));
            }
        }

        private string _encrypted;

        public string Encrypted
        {
            get => _encrypted;
            set
            {
                _encrypted = value;
                _decrypted = Decrypt(value);
                _passwordEncrypted = StringCipher.Encrypt(value, _password);
                OnPropertyChanged();
                OnPropertyChanged(nameof(DecryptedString));
                OnPropertyChanged(nameof(PasswordEncrypted));
            }
        }

        private string _passwordEncrypted;
        public string PasswordEncrypted
        {
            get => _passwordEncrypted;
            set
            {
                _passwordEncrypted = value;
                Encrypted = StringCipher.Decrypt(value, _password);
                OnPropertyChanged();
            }
        }

        private string _password;

        public string Password
        {
            get => _password;
            set
            {
                _password = value;
                OnPropertyChanged();
            }
        }

        public MainWindowViewModel()
        {
            Password = "password";
            Encrypted = string.Empty;
            Decrypted = new byte[] { };
        }




        private string Encrypt(byte[] value)
        {
            try
            {
                return Convert.ToBase64String(value);
            }
            catch(Exception e)
            {
                Debug.WriteLine(e);
                return string.Empty;
            }
        }

        private byte[] Decrypt(string value)
        {
            try
            {
                return Convert.FromBase64String(value);
            }
            catch(Exception e)
            {
                Debug.WriteLine(e);
                return new byte[] { };
            }
        }
    }
}
